<?php

namespace Zeobv\AbandonedCart\Service;

use Shopware\Core\Checkout\Cart\Cart;
use Shopware\Core\Checkout\Customer\SalesChannel\AccountService;
use Shopware\Core\Content\MailTemplate\MailTemplateEntity;
use Shopware\Core\Content\MailTemplate\Service\MailService;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\System\SalesChannel\Context\SalesChannelContextPersister;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Core\System\SalesChannel\SalesChannelEntity;
use Zeobv\AbandonedCart\Checkout\AbandonedCart\AbandonedCart;

class AbandonedCartService {
    /**
     * @var ConfigService
     */
    protected $configService;
    /**
     * @var MailService
     */
    protected $mailService;
    /**
     * @var EntityRepository
     */
    protected $mailTemplateRepository;
    /**
     * @var EntityRepository
     */
    protected $abandonedCartRepository;
    /**
     * @var CartService
     */
    protected $cartService;
    /**
     * @var SalesChannelContextPersister
     */
    protected $contextPersister;

    /**
     * AbandonedCartService constructor.
     *
     * @param ConfigService                $configService
     * @param EntityRepository             $abandonedCartRepository
     * @param EntityRepository             $mailTemplateRepository
     * @param MailService                  $mailService
     * @param CartService                  $cartService
     * @param SalesChannelContextPersister $contextPersister
     */
    public function __construct(
        ConfigService $configService,
        EntityRepository $abandonedCartRepository,
        EntityRepository $mailTemplateRepository,
        MailService $mailService,
        CartService $cartService,
        SalesChannelContextPersister $contextPersister
    ) {
        $this->configService = $configService;
        $this->mailService = $mailService;
        $this->mailTemplateRepository = $mailTemplateRepository;
        $this->abandonedCartRepository = $abandonedCartRepository;
        $this->cartService = $cartService;
        $this->contextPersister = $contextPersister;
    }

    /**
     * @param SalesChannelEntity $salesChannelEntity
     *
     * @return bool
     */
    public function isActive(SalesChannelEntity $salesChannelEntity): bool
    {
        return $this->configService->getIsActive($salesChannelEntity);
    }

    /**
     * @param AbandonedCart $abandonedCart
     *
     * @return bool
     */
    public function shouldProcessAbandonedCart(AbandonedCart $abandonedCart): bool
    {
        return $this->isActive($abandonedCart->getSalesChannel()) &&
               !$abandonedCart->getMailSend() &&
               $this->canProcessAbandonedCart($abandonedCart) &&
               $abandonedCart->getAge()->h >= $this->configService->getProcessStartDelay($abandonedCart->getSalesChannel());
    }

    /**
     * @param AbandonedCart $abandonedCart
     *
     * @return bool
     */
    public function canProcessAbandonedCart(AbandonedCart $abandonedCart): bool
    {
        return !is_null($abandonedCart->getEmail()) || !is_null($abandonedCart->getCustomer());
    }

    /**
     * @param AbandonedCart $abandonedCart
     *
     * @throws \Shopware\Core\Content\MailTemplate\Exception\SalesChannelNotFoundException
     * @throws \Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException
     */
    public function processAbandonedCart(AbandonedCart $abandonedCart)
    {
        $context = Context::createDefaultContext();
        $criteria = new Criteria();
        $criteria->addAssociation('mail_template_type.technicalName');
        $criteria->addFilter( new EqualsFilter('mailTemplateType.technicalName', 'abandoned_cart.reminder') );
        $result = $this->mailTemplateRepository->search($criteria, $context);

        if ($result->count() <= 0) {
            return;
        }

        /** @var MailTemplateEntity $template */
        $template = $result->first();

        # Map information of customer to template
        $mailData =  [
            'recipients' => [
                $abandonedCart->getCustomer()->getEmail() => $abandonedCart->getCustomer()->getFirstName()
            ],
            'salesChannelId' => $abandonedCart->getSalesChannelId(),
            'subject' => $template->getSubject(),
            'senderName' => $template->getSenderName(),
            'contentPlain' => $template->getContentPlain(),
            'contentHtml' => $template->getContentHtml(),
            'mediaIds' => []
        ];

        $templateData = $template->jsonSerialize();
        $templateData['zeoAbandonedCart'] = $abandonedCart;
        $templateData['salesChannel'] = $abandonedCart->getSalesChannel();
        $templateData['customer'] = $abandonedCart->getCustomer();

        # Create email
        $mailMessage = $this->mailService->send(
            $mailData,
            $context,
            $templateData
        );

        if ( $mailMessage instanceof \Swift_Message) {
            $this->abandonedCartRepository->update([
                ['id' => $abandonedCart->getId(), 'mailSend' => true]
            ], $context);
        }
    }

    /**
     * @param AbandonedCart $abandonedCart
     * @param Context       $context
     */
    public function resolveAbandonedCart(AbandonedCart $abandonedCart, Context $context)
    {
        # Cart is resolved to an order. The abandoned cart is no longer abandoned. Resolve the abandoned cart.
        $this->abandonedCartRepository->delete([
            ['id' => $abandonedCart->getId()]
        ], $context);
    }

    /**
     * An AbandonedCart should be trashed when it has been abandoned longer than the configured trash delay
     *
     * @param AbandonedCart $abandonedCart
     *
     * @return bool
     */
    public function shouldTrashAbandonedCart(AbandonedCart $abandonedCart): bool
    {
        return $abandonedCart->getAge()->h > $this->configService->getTrashDelay($abandonedCart->getSalesChannel()) ||
            (is_null($abandonedCart->getEmail()) && is_null($abandonedCart->getCustomer()));
    }

    /**
     * @param AbandonedCart $abandonedCart
     * @param Context       $context
     */
    public function trashAbandonedCart(AbandonedCart $abandonedCart, Context $context)
    {
        $this->abandonedCartRepository->delete([
            ['id' => $abandonedCart->getId()]
        ], $context);
    }

    /**
     * @param AbandonedCart       $abandonedCart
     * @param SalesChannelContext $salesChannelContext
     *
     * @return Cart
     * @throws \Shopware\Core\Checkout\Cart\Exception\InvalidQuantityException
     * @throws \Shopware\Core\Checkout\Cart\Exception\LineItemNotStackableException
     * @throws \Shopware\Core\Checkout\Cart\Exception\MixedLineItemTypeException
     */
    public function recoverAbandonedCart(AbandonedCart $abandonedCart, SalesChannelContext $salesChannelContext)
    {
        $newCart = $this->cartService->createNewFromAbandonedCart($abandonedCart, $salesChannelContext);
        $this->cartService->populateCartFromAbandonedCart($newCart, $abandonedCart, $salesChannelContext);

        $this->setNewCart($abandonedCart, $newCart, $salesChannelContext);
        $this->resolveAbandonedCart($abandonedCart, $salesChannelContext->getContext());

        if (!$this->configService->getIsCartAnonymous($salesChannelContext->getSalesChannel()) && $abandonedCart->getCustomer()) {
            $this->contextPersister->save(
                $salesChannelContext->getToken(),
                [
                    'customerId' => $abandonedCart->getCustomer()->getId(),
                    'billingAddressId' => $abandonedCart->getCustomer()->getDefaultBillingAddress() ?
                        $abandonedCart->getCustomer()->getDefaultBillingAddress()->getId() : null,
                    'shippingAddressId' => $abandonedCart->getCustomer()->getDefaultShippingAddress() ?
                        $abandonedCart->getCustomer()->getDefaultShippingAddress() : null,
                ]
            );
        }

        return $newCart;
    }

    /**
     * @param AbandonedCart       $abandonedCart
     * @param Cart                $newCart
     * @param SalesChannelContext $salesChannelContext
     *
     * @throws
     */
    public function setNewCart(AbandonedCart $abandonedCart, Cart $newCart, SalesChannelContext $salesChannelContext)
    {
        $this->cartService->setCartToSession($newCart, $salesChannelContext);
        $this->cartService->deleteRelatedCart($abandonedCart, $salesChannelContext);
        $this->cartService->saveNewCart($newCart, $salesChannelContext);
    }

    public function saveCart(Cart $cart, SalesChannelContext $salesChannelContext)
    {
        $this->cartService->saveNewCart($cart, $salesChannelContext);
    }
}
