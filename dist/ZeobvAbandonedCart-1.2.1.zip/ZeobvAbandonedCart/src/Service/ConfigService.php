<?php

namespace Zeobv\AbandonedCart\Service;

use Shopware\Core\System\SalesChannel\SalesChannelEntity;
use Shopware\Core\System\SystemConfig\SystemConfigService;

class ConfigService {

    /**
     * @var SystemConfigService
     */
    protected $configService;

    /**
     * ConfigService constructor.
     *
     * @param SystemConfigService $configService
     */
    public function __construct(
        SystemConfigService $configService
    ) {
        $this->configService = $configService;
    }

    /**
     * @param SalesChannelEntity $salesChannelEntity
     *
     * @return bool|null
     */
    public function getIsActive(SalesChannelEntity $salesChannelEntity): ?bool
    {
        $isActive = $this->configService->get('ZeobvAbandonedCart.config.active', $salesChannelEntity->getId());
        return $isActive ? $isActive : false;
    }

    /**
     * @param SalesChannelEntity $salesChannelEntity
     *
     * @return int
     */
    public function getProcessStartDelay(SalesChannelEntity $salesChannelEntity): int
    {
        $mailSendDelay = $this->configService->get('ZeobvAbandonedCart.config.mailSendDelay', $salesChannelEntity->getId());
        return $mailSendDelay ? $mailSendDelay : 1;
    }

    /**
     * @param SalesChannelEntity $salesChannelEntity
     *
     * @return int
     */
    public function getTrashDelay(SalesChannelEntity $salesChannelEntity): int
    {
        $decayTime = $this->configService->get('ZeobvAbandonedCart.config.abandonedCartDecay', $salesChannelEntity->getId());
        return $decayTime ? $decayTime : 24;
    }

    /**
     * @param SalesChannelEntity $salesChannelEntity
     *
     * @return int
     */
    public function getIsCartAnonymous(SalesChannelEntity $salesChannelEntity): int
    {
        $cartIsAnonymous = $this->configService->get('ZeobvAbandonedCart.config.isCartAnonymous', $salesChannelEntity->getId());
        return $cartIsAnonymous ? $cartIsAnonymous : false;
    }
}
