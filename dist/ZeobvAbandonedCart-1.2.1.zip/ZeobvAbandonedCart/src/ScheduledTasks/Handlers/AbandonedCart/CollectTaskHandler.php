<?php declare(strict_types=1);

namespace Zeobv\AbandonedCart\ScheduledTasks\Handlers\AbandonedCart;

use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\MessageQueue\ScheduledTask\ScheduledTaskHandler;
use Shopware\Core\System\SalesChannel\SalesChannelCollection;
use Shopware\Core\System\SalesChannel\SalesChannelEntity;
use Zeobv\AbandonedCart\Checkout\AbandonedCart\AbandonedCart;
use Zeobv\AbandonedCart\ScheduledTasks\Tasks\AbandonedCart\CollectTask;
use Zeobv\AbandonedCart\Service\AbandonedCartService;

class CollectTaskHandler extends ScheduledTaskHandler
{
    /**
     * @var EntityRepositoryInterface
     */
    protected $abandonedCartRepository;

    /**
     * @var EntityRepositoryInterface
     */
    protected $salesChannelRepository;

    /**
     * @var AbandonedCartService
     */
    protected $abandonedCartService;

    /**
     * CollectTaskHandler constructor.
     *
     * @param EntityRepositoryInterface $scheduledTaskRepository
     * @param EntityRepositoryInterface $abandonedCartRepository
     * @param EntityRepositoryInterface $salesChannelRepository
     * @param AbandonedCartService      $abandonedCartService
     */
    public function __construct(
        EntityRepositoryInterface $scheduledTaskRepository,
        EntityRepositoryInterface $abandonedCartRepository,
        EntityRepositoryInterface $salesChannelRepository,
        AbandonedCartService $abandonedCartService
    )
    {
        $this->abandonedCartRepository = $abandonedCartRepository;
        $this->salesChannelRepository = $salesChannelRepository;
        $this->abandonedCartService = $abandonedCartService;

        parent::__construct($scheduledTaskRepository);
    }

    /**
     * @return iterable
     */
    public static function getHandledMessages(): iterable
    {
        return [CollectTask::class];
    }

    /**
     * Collects all abandoned carts and starts the abandoned cart process
     *
     * @throws \Shopware\Core\Content\MailTemplate\Exception\SalesChannelNotFoundException
     * @throws \Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException
     */
    public function run(): void
    {
        $salesChannelCollection = $this->getSalesChannels();
        $context = Context::createDefaultContext();

        if (is_null($salesChannelCollection)) {
            return;
        }

        /** @var SalesChannelEntity $salesChannelEntity */
        foreach ($salesChannelCollection as $salesChannelEntity) {
            if ( !$this->abandonedCartService->isActive($salesChannelEntity) ) continue;

            $criteria = new Criteria();
            $criteria->addFilter(new EqualsFilter('salesChannelId', $salesChannelEntity->getId()));
            $criteria->addAssociations(['customer', 'sales_channel']);
            $result = $this->abandonedCartRepository->search($criteria, $context);

            if ($result->getTotal() <= 0) {
                continue;
            }

            /** @var AbandonedCart $abandonedCart */
            foreach ($result->getElements() as $abandonedCart) {
                # Check if abandoned cart should be processed
                if ($this->abandonedCartService->shouldProcessAbandonedCart($abandonedCart)) {
                    # Process abandoned cart
                    $this->abandonedCartService->processAbandonedCart($abandonedCart);
                } elseif ($this->abandonedCartService->shouldTrashAbandonedCart($abandonedCart)) {
                    # Trash abandoned cart
                    $this->abandonedCartService->trashAbandonedCart($abandonedCart, $context);
                }
            }
        }
    }

    /**
     * @return SalesChannelCollection
     * @throws \Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException
     */
    protected function getSalesChannels(): ?SalesChannelCollection
    {
        $result = $this->salesChannelRepository->search(
            new Criteria(),
            Context::createDefaultContext()
        );

        if ( $result->count() <= 0 )
            return null;

        /** @var SalesChannelCollection $salesChannelCollection */
        $salesChannelCollection = $result->getEntities();

        return $salesChannelCollection;
    }
}
