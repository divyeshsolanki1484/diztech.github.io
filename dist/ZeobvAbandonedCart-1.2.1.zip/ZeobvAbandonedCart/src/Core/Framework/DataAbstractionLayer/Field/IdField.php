<?php declare(strict_types=1);

namespace Zeobv\AbandonedCart\Core\Framework\DataAbstractionLayer\Field;

use Shopware\Core\Framework\DataAbstractionLayer\FieldSerializer\IdFieldSerializer;
use Zeobv\AbandonedCart\Core\Framework\DataAbstractionLayer\FieldSerializer\IdNullableFieldSerializer;

class IdField extends \Shopware\Core\Framework\DataAbstractionLayer\Field\IdField
{
    protected $nullable;

    public function __construct(
        string $storageName,
        string $propertyName,
        bool $nullable = false
    ) {
        $this->nullable = $nullable;
        parent::__construct($storageName, $propertyName);
    }

    protected function getSerializerClass(): string
    {
        if (!$this->nullable) {
            return IdFieldSerializer::class;
        } else {
            return IdNullableFieldSerializer::class;
        }
    }
}
