<?php declare(strict_types=1);

namespace Zeobv\AbandonedCart;

use Shopware\Core\Content\MailTemplate\Aggregate\MailTemplateType\MailTemplateTypeEntity;
use Shopware\Core\Defaults;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Plugin;
use Shopware\Core\Framework\Plugin\Context\InstallContext;

class ZeobvAbandonedCart extends Plugin
{
    const MAIL_TEMPLATE_REMINDER_NAME = 'abandoned_cart.reminder';

    public function install(InstallContext $installContext): void
    {
        $mailTemplateRepository = $this->container->get('mail_template.repository');
        $mailTemplateTypeRepository = $this->container->get('mail_template_type.repository');

        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('technicalName', self::MAIL_TEMPLATE_REMINDER_NAME));
        $templateType = $mailTemplateTypeRepository->search($criteria, $installContext->getContext())->first();

        if ( $templateType instanceof MailTemplateTypeEntity) {
            return;
        }

        $mailTemplateRepository->create([
            [
                'systemDefault' => false,
                'translations' => [
                    [
                        'languageId' => Defaults::LANGUAGE_SYSTEM,
                        'subject' => 'Your cart is waiting for you',
                        'description' => 'Mail template send to customer who abandoned a shopping cart for longer than the configured time.',
                        'senderName' => '{{ salesChannel.name }}',
                        'contentPlain' => 'Your cart is waiting for you. Use the following link to go to checkout {{ zeoAbandonedCart.salesChannelDomain.url }}{{ path(\'frontend.zeo.abandonedcart.recover\', {id: zeoAbandonedCart.id}) }}',
                        'contentHtml' => '<h2>Your cart is waiting for you.</h2>
<p>Click the following link to proceed to checkout.<br/>
    <a href="{{ zeoAbandonedCart.salesChannelDomain.url }}{{ path(\'frontend.zeo.abandonedcart.recover\', {id: zeoAbandonedCart.id}) }}">
        <button>Go to checkout</button>
    </a>
</p>'
                    ]
                ],
                'mailTemplateType' => [
                    'technicalName' => self::MAIL_TEMPLATE_REMINDER_NAME,
                    'availableEntities' => [
                        'zeoAbandonedCart' => 'zeo_abandoned_cart',
                        'salesChannel' => 'sales_channel',
                        'customer' => 'customer'
                    ],
                    'translations' => [
                        [
                            'languageId' => Defaults::LANGUAGE_SYSTEM,
                            'name' => 'Enter abandoned cart state: Reminded'
                        ],
                    ]
                ]
            ]
        ], $installContext->getContext());
    }
}
