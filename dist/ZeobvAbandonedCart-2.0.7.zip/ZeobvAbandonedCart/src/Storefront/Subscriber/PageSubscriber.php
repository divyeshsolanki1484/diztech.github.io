<?php

declare(strict_types=1);

namespace Zeobv\AbandonedCart\Storefront\Subscriber;

use Shopware\Core\Checkout\Cart\Cart;
use Shopware\Core\Checkout\Cart\Event\AfterLineItemAddedEvent;
use Shopware\Core\Checkout\Cart\Event\AfterLineItemQuantityChangedEvent;
use Shopware\Core\Checkout\Cart\Event\AfterLineItemRemovedEvent;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Storefront\Page\Account\Overview\AccountOverviewPageLoadedEvent;
use Shopware\Storefront\Page\Checkout\Confirm\CheckoutConfirmPageLoadedEvent;
use Shopware\Storefront\Page\Checkout\Offcanvas\OffcanvasCartPageLoadedEvent;
use Shopware\Storefront\Page\Checkout\Register\CheckoutRegisterPageLoadedEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;
use Zeobv\AbandonedCart\Checkout\AbandonedCart\AbandonedCart;
use Zeobv\AbandonedCart\Pagelet\AbandonedCartReminder\Account\AbandonedCartReminderAccountPageletLoader;
use Zeobv\AbandonedCart\Pagelet\AbandonedCartReminder\Account\AbandonedCartReminderPagelet;
use Zeobv\AbandonedCart\Service\AbandonedCartService;

class PageSubscriber implements EventSubscriberInterface
{
    protected ?Request $currentRequest;

    public function __construct(
        RequestStack $requestStack,
        private EntityRepository $abandonedCartRepository,
        private AbandonedCartService $abandonedCartService,
        private AbandonedCartReminderAccountPageletLoader $abandonedCartReminderAccountPageletLoader
    )
    {
        $this->currentRequest = $requestStack->getCurrentRequest();
    }

    public static function getSubscribedEvents(): array
    {
        return [
            AccountOverviewPageLoadedEvent::class => 'onAccountOverviewLoaded',
            AfterLineItemAddedEvent::class => 'onLineItemAdded',
            AfterLineItemQuantityChangedEvent::class => 'onLineItemQtyChanged',
            AfterLineItemRemovedEvent::class => 'onLineItemRemoved',
            OffcanvasCartPageLoadedEvent::class => 'onOffcanvasCartPageLoaded',
            CheckoutRegisterPageLoadedEvent::class => 'onCheckoutRegisterPageLoaded',
            CheckoutConfirmPageLoadedEvent::class => 'onCheckoutConfirmPageLoaded',
        ];
    }

    public function onAccountOverviewLoaded(AccountOverviewPageLoadedEvent $event): void
    {
        $event->getPage()->addExtension(
            AbandonedCartReminderPagelet::EXTENSION_NAME,
            $this->abandonedCartReminderAccountPageletLoader->load(
                $event->getPage()->getCustomer()
            )
        );
    }

    public function onLineItemAdded(AfterLineItemAddedEvent $event): void
    {
        $cart = $event->getCart();

        $salesChannelContext = $event->getSalesChannelContext();

        if ($this->currentRequest->attributes->get('sw-domain-id')) {
            $this->upsertAbandonedCart($cart, $salesChannelContext, true);
        }
    }

    public function onLineItemRemoved(AfterLineItemRemovedEvent $event): void
    {
        $cart = $event->getCart();

        $salesChannelContext = $event->getSalesChannelContext();

        if ($this->currentRequest->attributes->get('sw-domain-id')) {
            $this->upsertAbandonedCart($cart, $salesChannelContext, true);
        }
    }

    public function onLineItemQtyChanged(AfterLineItemQuantityChangedEvent $event): void
    {
        $cart = $event->getCart();

        $salesChannelContext = $event->getSalesChannelContext();

        if ($this->currentRequest->attributes->get('sw-domain-id')) {
            $this->upsertAbandonedCart($cart, $salesChannelContext, true);
        }
    }

    public function onOffcanvasCartPageLoaded(OffcanvasCartPageLoadedEvent $event): void
    {
        $cart = $event->getPage()->getCart();
        $this->abandonedCartService->saveCart($cart, $event->getSalesChannelContext());
        $this->upsertAbandonedCart($cart, $event->getSalesChannelContext());
    }

    public function onCheckoutConfirmPageLoaded(CheckoutConfirmPageLoadedEvent $event): void
    {
        $cart = $event->getPage()->getCart();
        $this->abandonedCartService->saveCart($cart, $event->getSalesChannelContext());
        $this->upsertAbandonedCart($cart, $event->getSalesChannelContext());
    }

    public function onCheckoutRegisterPageLoaded(CheckoutRegisterPageLoadedEvent $event): void
    {
        $cart = $event->getPage()->getCart();
        $this->abandonedCartService->saveCart($cart, $event->getSalesChannelContext());
        $this->upsertAbandonedCart($cart, $event->getSalesChannelContext());
    }

    protected function upsertAbandonedCart(Cart $cart, SalesChannelContext $context, bool $cartShouldExist = false): void
    {
        $customer = $context->getCustomer();
        if (is_null($customer)) {
            return;
        }

        $salesChannelDomainId = $this->currentRequest->attributes->get('sw-domain-id');

        if (is_null($salesChannelDomainId)) {
            return;
        }

        $criteria = new Criteria();

        # Get abandoned cart by customer email to avoid abandoned cart duplication.
        $criteria->addFilter(new EqualsFilter('email', $customer->getEmail()));

        $cartResult = $this->abandonedCartRepository->search($criteria, $context->getContext());

        if ($cartShouldExist && $cartResult->count() <= 0) {
            return;
        }

        $lineItems = json_encode($cart->getLineItems()->getElements());

        if ($lineItems === false) {
            return;
        }

        $lineItems = json_decode($lineItems, true);

        /** @var AbandonedCart|null $abandonedCart */
        $abandonedCart = $cartResult->first();

        if (empty($lineItems)) {
            $id = $abandonedCart ? $abandonedCart->getId() : null;
            if ($id !== null) {
                $this->abandonedCartRepository->delete([
                    [
                        'id' => $id,
                    ],
                ], $context->getContext());
            }
            return;
        }

        $data = [
            'id' => $abandonedCart ? $abandonedCart->getId() : Uuid::randomHex(),
            'cartToken' => $cart->getToken(),
            'lineItems' => $lineItems,
            'currencyId' => $context->getCurrency()->getId(),
            'paymentMethodId' => $context->getPaymentMethod()->getId(),
            'shippingMethodId' => $context->getShippingMethod()->getId(),
            'countryId' => $context->getShippingLocation()->getCountry()->getId(),
            'salesChannelId' => $context->getSalesChannel()->getId(),
            'salesChannelDomainId' => $salesChannelDomainId,
            'customerId' => $customer->getId(),
            'email' => $customer->getEmail(),
        ];

        $this->abandonedCartRepository->upsert([$data], $context->getContext());
    }
}
