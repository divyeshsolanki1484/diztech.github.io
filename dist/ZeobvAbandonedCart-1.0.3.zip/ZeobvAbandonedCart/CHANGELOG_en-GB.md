# 1.0.3
- Patched issue where not all abandoned carts would be processed if a sales channel didn't have any abandoned carts.

# 1.0.2
- Patched issue where no new cart would be created using the link in the abandoned cart email
- Added logo

# 1.0.1
- Compatibility fixes for Shopware 6.1.0-rc3

# 1.0.0
- First version of the Zeo Abandoned Cart for Shopware 6
