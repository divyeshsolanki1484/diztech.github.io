<?php

namespace Zeobv\AbandonedCart\Service;

use Shopware\Core\Checkout\Cart\Cart;
use Shopware\Core\Checkout\Cart\CartPersister;
use Shopware\Core\Checkout\Cart\LineItem\LineItem;
use Shopware\Core\Checkout\Cart\LineItem\LineItemCollection;
use Shopware\Core\Checkout\Cart\SalesChannel\CartService as SwCartService;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Zeobv\AbandonedCart\Checkout\AbandonedCart\AbandonedCart;

class CartService {
    /**
     * @var SwCartService
     */
    protected $cartService;
    /**
     * @var CartPersister
     */
    protected $cartPersister;

    /**
     * CartService constructor.
     *
     * @param SwCartService      $cartService
     * @param CartPersister    $cartPersister
     */
    public function __construct(
        SwCartService $cartService,
        CartPersister $cartPersister
    ) {
        $this->cartService = $cartService;
        $this->cartPersister = $cartPersister;
    }

    /**
     * @param AbandonedCart       $abandonedCart
     * @param SalesChannelContext $salesChannelContext
     *
     * @return Cart
     */
    public function createNewFromAbandonedCart(AbandonedCart $abandonedCart, SalesChannelContext $salesChannelContext)
    {
        return $this->cartService->createNew($salesChannelContext->getToken(), $abandonedCart->getId());
    }

    /**
     * @param Cart          $cart
     * @param AbandonedCart $abandonedCart
     *
     * @return Cart
     * @throws \Shopware\Core\Checkout\Cart\Exception\InvalidQuantityException
     * @throws \Shopware\Core\Checkout\Cart\Exception\LineItemNotStackableException
     * @throws \Shopware\Core\Checkout\Cart\Exception\MixedLineItemTypeException
     */
    public function populateCartFromAbandonedCart(Cart &$cart, AbandonedCart $abandonedCart)
    {
        $lineItems = array_map(function (array $lineItemData) {
            $lineItem = new LineItem(
                $lineItemData['id'],
                $lineItemData['type'],
                $lineItemData['referencedId'],
                $lineItemData['quantity']
            );

            return $lineItem->setPayload($lineItemData['payload']);
        }, $abandonedCart->getLineItems());

        $lineItems = new LineItemCollection($lineItems);

        $cart->addLineItems($lineItems);

        return $cart;
    }

    /**
     * @param Cart                $cart
     * @param SalesChannelContext $salesChannelContext
     */
    public function setCartToSession(Cart &$cart, SalesChannelContext $salesChannelContext)
    {
        $this->cartService->setCart($cart, $salesChannelContext);
    }

    /**
     * @param AbandonedCart       $abandonedCart
     * @param SalesChannelContext $salesChannelContext
     */
    public function deleteRelatedCart(AbandonedCart $abandonedCart, SalesChannelContext $salesChannelContext)
    {
        $this->cartPersister->delete($abandonedCart->getCartToken(), $salesChannelContext);
    }
}
