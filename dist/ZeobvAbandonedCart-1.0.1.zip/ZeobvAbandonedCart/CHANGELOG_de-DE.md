# 1.0.1
- Kompatibilitätskorrekturen für Shopware 6.1.0-rc3

# 1.0.0
- Erste Version des Zeo Abandoned Cart für Shopware 6
