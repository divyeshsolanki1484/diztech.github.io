# 1.0.1
- Compatibility fixes for Shopware 6.1.0-rc3

# 1.0.0
- First version of the Zeo Abandoned Cart for Shopware 6
