<?php

declare(strict_types=1);

namespace Zeobv\AbandonedCart\Service;

use Shopware\Core\Checkout\Cart\Cart;
use Shopware\Core\Checkout\Customer\CustomerEntity;
use Shopware\Core\Content\Mail\Service\AbstractMailService as MailService;
use Shopware\Core\Content\MailTemplate\MailTemplateEntity;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\System\SalesChannel\Context\CachedSalesChannelContextFactory;
use Shopware\Core\System\SalesChannel\Context\SalesChannelContextPersister;
use Shopware\Core\System\SalesChannel\Context\SalesChannelContextService;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Symfony\Component\Routing\RouterInterface;
use Zeobv\AbandonedCart\Checkout\AbandonedCart\AbandonedCart;

class AbandonedCartService
{
    public const REMINDER_MAIL_STATUS_SUBSCRIBED = 'subscribed';
    public const REMINDER_MAIL_STATUS_UNSUBSCRIBED = 'unsubscribed';
    public const REMINDER_STATUS_FIELD_NAME = 'zeobvAbandonedCartSubscriptionStatus';

    public function __construct(
        private ConfigService $configService,
        private EntityRepository $abandonedCartRepository,
        private EntityRepository $mailTemplateRepository,
        private MailService $mailService,
        private CartService $cartService,
        private SalesChannelContextPersister $contextPersister,
        private CachedSalesChannelContextFactory $salesChannelContextFactory,
        private RouterInterface $router
    ) {
    }

    public function shouldProcessAbandonedCart(AbandonedCart $abandonedCart): bool
    {
        $salesChannel = $abandonedCart->getSalesChannel();
        $lastMailWasSendAt = $abandonedCart->getLastMailSendAt() ?? (! is_null($abandonedCart->getUpdatedAt()) ? $abandonedCart->getUpdatedAt() : $abandonedCart->getCreatedAt());
        $minutesSinceLastMailWasSend = (time() - $lastMailWasSendAt->getTimestamp()) / 60;

        $schedule = $this->configService->getSchedule($salesChannel);

        if (! empty($schedule)) {
            if (! key_exists($abandonedCart->getScheduleIndex(), $schedule)) {
                return false;
            }

            $scheduledDelaySinceLastMail = $schedule[$abandonedCart->getScheduleIndex()]['delay'];
        } else {
            $scheduledDelaySinceLastMail = $this->configService->getProcessStartDelay($salesChannel) * 60;
        }

        return $this->configService->getIsActive($salesChannel) &&
            $this->canProcessAbandonedCart($abandonedCart) &&
            $minutesSinceLastMailWasSend >= $scheduledDelaySinceLastMail;
    }

    public function canProcessAbandonedCart(AbandonedCart $abandonedCart): bool
    {
        if ($abandonedCart->getCustomer() instanceof CustomerEntity) {
            $customFields = $abandonedCart->getCustomer()->getCustomFields();
            return ! is_array($customFields)
                || ! key_exists(self::REMINDER_STATUS_FIELD_NAME, $customFields)
                || $customFields[self::REMINDER_STATUS_FIELD_NAME] === self::REMINDER_MAIL_STATUS_SUBSCRIBED;
        }

        return ! is_null($abandonedCart->getEmail());
    }

    /**
     * Bool returns if cart was successfully processed.
     */
    public function processAbandonedCart(AbandonedCart $abandonedCart): bool
    {
        // Load the SalesChannel context of the abandoned cart
        $salesChannelContext = $this->salesChannelContextFactory->create(
            Uuid::randomHex(),
            $abandonedCart->getSalesChannelId(),
            [
                SalesChannelContextService::LANGUAGE_ID => $abandonedCart->getSalesChannelDomain()->getLanguageId(),
            ]
        );

        // Use the context of the Abandoned Cart SalesChannel
        $context = $salesChannelContext->getContext();

        // Create New cart
        $newCart = $this->cartService->createNewFromAbandonedCart($abandonedCart, $salesChannelContext);
        $this->cartService->populateCartFromAbandonedCart($newCart, $abandonedCart);
        $cart = $this->cartService->recalculate($newCart, $salesChannelContext);

        // Setup the Symfony router context to simulate the Abandoned Cart SalesChannelDomain.
        // In console context the router context is not set and urls in email would fallback to http://localhost
        $originalRouterContext = clone $this->router->getContext();
        $this->switchRouterContext($abandonedCart->getSalesChannelDomain()->getUrl());

        /** @var MailTemplateEntity|null $mailTemplate */
        $mailTemplate = $this->getMailTemplate($abandonedCart, $context);

        if (is_null($mailTemplate)) {
            return false;
        }

        # Map information of customer to template
        $mailData = [
            'recipients' => [
                $abandonedCart->getCustomer()->getEmail() => $abandonedCart->getCustomer()->getFirstName(),
            ],
            'salesChannelId' => $abandonedCart->getSalesChannelId(),
            'subject' => $mailTemplate->getTranslation('subject'),
            'senderName' => $mailTemplate->getTranslation('senderName'),
            'contentPlain' => $mailTemplate->getTranslation('contentPlain'),
            'contentHtml' => $mailTemplate->getTranslation('contentHtml'),
            'mediaIds' => [],
        ];

        $templateData = $mailTemplate->jsonSerialize();
        $templateData['zeoAbandonedCart'] = $abandonedCart;
        $templateData['cart'] = $cart;
        $templateData['customer'] = $abandonedCart->getCustomer();

        # Create email
        $mailMessage = $this->mailService->send(
            $mailData,
            $context,
            $templateData
        );

        /* Here we are fetching the value of mail sent from config and increment the value every time on mail is sent. */
        if ($mailMessage !== null) {
            if ($abandonedCart->getScheduleIndex() === 0) {
                $metricMailsSent = $this->configService->getMetricMailsSent($abandonedCart->getSalesChannel());
                $incrementMailSent = $metricMailsSent + 1;
                $this->configService->setMetricMailsSent($incrementMailSent);
            }

            $this->abandonedCartRepository->update([
                [
                    'id' => $abandonedCart->getId(),
                    'scheduleIndex' => $abandonedCart->getScheduleIndex() + 1,
                    'lastMailSendAt' => new \DateTime(),
                ],
            ], $context);

            return true;
        }

        // Switch back to original router context
        $this->router->setContext($originalRouterContext);

        return false;
    }

    public function resolveAbandonedCart(AbandonedCart $abandonedCart, Context $context): void
    {
        # Cart is resolved to an order. The abandoned cart is no longer abandoned. Resolve the abandoned cart.
        $this->abandonedCartRepository->delete([
            ['id' => $abandonedCart->getId()],
        ], $context);
    }

    /**
     * An AbandonedCart should be trashed when it has been abandoned longer than the configured trash delay
     */
    public function shouldTrashAbandonedCart(AbandonedCart $abandonedCart): bool
    {
        $age = $abandonedCart->getAge();
        $ageInHours = ($age->d * 24) + $age->h + ($age->i / 60);

        return ! $this->canProcessAbandonedCart($abandonedCart) ||
            $ageInHours > $this->configService->getTrashDelay($abandonedCart->getSalesChannel());
    }

    public function trashAbandonedCart(AbandonedCart $abandonedCart, Context $context): void
    {
        $this->abandonedCartRepository->delete([
            ['id' => $abandonedCart->getId()],
        ], $context);
    }

    public function recoverAbandonedCart(AbandonedCart $abandonedCart, SalesChannelContext $salesChannelContext): Cart
    {
        $newCart = $this->cartService->createNewFromAbandonedCart($abandonedCart, $salesChannelContext);
        $this->cartService->populateCartFromAbandonedCart($newCart, $abandonedCart);

        $this->setNewCart($abandonedCart, $newCart, $salesChannelContext);

        if (! $this->configService->getIsCartAnonymous($salesChannelContext->getSalesChannel()) && $abandonedCart->getCustomer()) {
            $this->contextPersister->save(
                $salesChannelContext->getToken(),
                [
                    'customerId' => $abandonedCart->getCustomer()->getId(),
                    'billingAddressId' => $abandonedCart->getCustomer()->getDefaultBillingAddress() ?
                    $abandonedCart->getCustomer()->getDefaultBillingAddress()->getId() : null,
                    'shippingAddressId' => $abandonedCart->getCustomer()->getDefaultShippingAddress() ?
                    $abandonedCart->getCustomer()->getDefaultShippingAddress()->getId() : null,
                ],
                $salesChannelContext->getSalesChannelId()
            );
        }

        return $newCart;
    }

    public function setNewCart(AbandonedCart $abandonedCart, Cart $newCart, SalesChannelContext $salesChannelContext): void
    {
        $this->cartService->setCartToSession($newCart);
        $this->cartService->deleteRelatedCart($abandonedCart, $salesChannelContext);
        $this->cartService->saveNewCart($newCart, $salesChannelContext);
    }

    public function saveCart(Cart $cart, SalesChannelContext $salesChannelContext): void
    {
        $this->cartService->saveNewCart($cart, $salesChannelContext);
    }

    /**
     * Switches the Symfony router context to another url
     * https://symfony.com/doc/4.4/routing.html#generating-urls-in-commands
     *
     *
     * Copied from Shopware:
     * Shopware\Storefront\Controller\ContextController@switchLanguage
     */
    protected function switchRouterContext(string $url): void
    {
        $parsedUrl = parse_url($url);

        $routerContext = $this->router->getContext();
        $routerContext->setHttpPort($parsedUrl['port'] ?? 80);
        $routerContext->setMethod('GET');
        $routerContext->setHost($parsedUrl['host']);
        $routerContext->setBaseUrl(rtrim($parsedUrl['path'] ?? '', '/'));
    }

    private function getMailTemplate(AbandonedCart $abandonedCart, Context $context): ?MailTemplateEntity
    {
        $schedule = $this->configService->getSchedule($abandonedCart->getSalesChannel());

        if (! key_exists($abandonedCart->getScheduleIndex(), $schedule)) {
            return null;
        }

        $scheduleConfig = $schedule[$abandonedCart->getScheduleIndex()];

        $criteria = new Criteria([$scheduleConfig['templateId']]);
        $criteria->addAssociation('mailTemplateType');

        return $this->mailTemplateRepository->search($criteria, $context)->first();
    }
}
