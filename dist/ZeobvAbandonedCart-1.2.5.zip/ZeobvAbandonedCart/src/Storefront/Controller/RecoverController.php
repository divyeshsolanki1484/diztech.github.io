<?php declare(strict_types=1);

namespace Zeobv\AbandonedCart\Storefront\Controller;

use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\Routing\Annotation\RouteScope;
use Shopware\Core\Framework\Uuid\Exception\InvalidUuidException;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Storefront\Controller\StorefrontController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Zeobv\AbandonedCart\Checkout\AbandonedCart\AbandonedCart;
use Zeobv\AbandonedCart\Service\AbandonedCartService;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;

/**
 * @RouteScope(scopes={"storefront"})
 */
class RecoverController extends StorefrontController
{
    /**
     * @var EntityRepositoryInterface
     */
    protected $abandonedCartRepository;
    /**
     * @var AbandonedCartService
     */
    protected $abandonedCartService;

    /**
     * RecoverController constructor.
     *
     * @param EntityRepositoryInterface $abandonedCartRepository
     * @param AbandonedCartService      $abandonedCartService
     */
    public function __construct(
        EntityRepositoryInterface $abandonedCartRepository,
        AbandonedCartService $abandonedCartService
    )
    {
        $this->abandonedCartRepository = $abandonedCartRepository;
        $this->abandonedCartService = $abandonedCartService;
    }

    /**
     * @Route("/zeo/abandonedcart/recover/{id}", name="frontend.zeo.abandonedcart.recover", options={"seo"="false"}, methods={"GET"})
     *
     * @param Request             $request
     * @param Context             $context
     * @param SalesChannelContext $salesChannelContext
     *
     * @return string
     * @throws \Exception
     */
    public function recover(Request $request, Context $context, SalesChannelContext $salesChannelContext)
    {
        $id = $request->get('id');

        if (empty($id)) {
            return $this->redirect('/');
        }

        $abandonedCart = $this->getAbandonedCartForId($id, $context);

        if (is_null($abandonedCart)) {
            return $this->redirect('/');
        }

        $this->abandonedCartService->recoverAbandonedCart($abandonedCart, $salesChannelContext);

        return $this->redirectToRoute('frontend.checkout.register.page');
    }

    /**
     * @param string  $id
     * @param Context $context
     *
     * @return AbandonedCart|null
     */
    protected function getAbandonedCartForId(string $id, Context $context): ?AbandonedCart
    {
        try {
            $criteria = new Criteria([strtolower($id)]);
            $result = $this->abandonedCartRepository->search($criteria, $context);
            $abandonedCart = $result->first();
        } catch (InconsistentCriteriaIdsException $e) {
            $abandonedCart = null;
        } catch (InvalidUuidException $e) {
            $abandonedCart = null;
        }

        return $abandonedCart;
    }
}
