<?php declare(strict_types=1);

namespace Zeobv\AbandonedCart\ScheduledTasks\Handlers\AbandonedCart;

use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\MessageQueue\ScheduledTask\ScheduledTaskHandler;
use Shopware\Core\System\SalesChannel\SalesChannelCollection;
use Shopware\Core\System\SalesChannel\SalesChannelEntity;
use Zeobv\AbandonedCart\Checkout\AbandonedCart\AbandonedCart;
use Zeobv\AbandonedCart\ScheduledTasks\Tasks\AbandonedCart\CollectTask;
use Zeobv\AbandonedCart\Service\AbandonedCartService;
use Throwable;
use Shopware\Core\Framework\DataAbstractionLayer\Search\EntitySearchResult;
use Psr\Log\LoggerInterface;
use Zeobv\AbandonedCart\Service\ConfigService;

class CollectTaskHandler extends ScheduledTaskHandler
{
    protected string $environment;
    protected EntityRepositoryInterface $abandonedCartRepository;
    protected EntityRepositoryInterface $salesChannelRepository;
    protected AbandonedCartService $abandonedCartService;
    protected ConfigService $configService;
    protected LoggerInterface $logger;

    public function __construct(
        string $environment,
        EntityRepositoryInterface $scheduledTaskRepository,
        EntityRepositoryInterface $abandonedCartRepository,
        EntityRepositoryInterface $salesChannelRepository,
        AbandonedCartService $abandonedCartService,
        ConfigService $configService,
        LoggerInterface $logger
    )
    {
        $this->environment = $environment;
        $this->abandonedCartRepository = $abandonedCartRepository;
        $this->salesChannelRepository = $salesChannelRepository;
        $this->abandonedCartService = $abandonedCartService;
        $this->configService = $configService;
        $this->logger = $logger;

        parent::__construct($scheduledTaskRepository);
    }

    /**
     * @return iterable
     */
    public static function getHandledMessages(): iterable
    {
        return [CollectTask::class];
    }

    /**
     * Collects all abandoned carts and starts the abandoned cart process
     */
    public function run(): void
    {
        try {
            $salesChannelCollection = $this->getSalesChannels();

            if (is_null($salesChannelCollection)) {
                return;
            }

            $context = $this->getContext();
            $this->configService->setLastRunTimestamp();

            foreach ($salesChannelCollection as $salesChannelEntity) {
                $cartsProcessedForSalesChannel = 0;
                $notificationBatchSize = $this->configService->getNotificationBatchSize($salesChannelEntity);

                if (!$this->configService->getIsActive($salesChannelEntity)) {
                    continue;
                }

                $this->configService->setLastRunTimestamp($salesChannelEntity);

                $result = $this->getAbandonedCartsForSalesChannel($salesChannelEntity, $context);

                if (is_null($result) || $result->getTotal() <= 0) {
                    continue;
                }

                /** @var AbandonedCart $abandonedCart */
                foreach ($result->getElements() as $abandonedCart) {
                    try {
                        if ($this->processAbandonedCart($abandonedCart, $context)) {
                            $cartsProcessedForSalesChannel++;
                        }
                    } catch (Throwable $e) {
                        $this->logOrThrowException($e);
                    }
                    if ($cartsProcessedForSalesChannel >= $notificationBatchSize) {
                        # If the batch size is reached, stop sending mails for this Sales Channel until the next run
                        break;
                    }
                }
            }
        } catch (Throwable $e) {
            $this->logOrThrowException($e);
        }
    }

    /**
     * @param AbandonedCart $abandonedCart
     * @param Context       $context
     *
     * @return bool
     * @throws Throwable
     */
    protected function processAbandonedCart(AbandonedCart $abandonedCart, Context $context): bool
    {
        try {
            # Check if abandoned cart should be processed
            if ($this->abandonedCartService->shouldProcessAbandonedCart($abandonedCart)) {
                # Process abandoned cart
                return $this->abandonedCartService->processAbandonedCart($abandonedCart);
            } elseif ($this->abandonedCartService->shouldTrashAbandonedCart($abandonedCart)) {
                # Trash abandoned cart
                $this->abandonedCartService->trashAbandonedCart($abandonedCart, $context);

                return false;
            }
        } catch (Throwable $e) {
            $this->logOrThrowException($e);
        }

        return false;
    }

    /**
     * @param SalesChannelEntity $salesChannelEntity
     * @param Context            $context
     *
     * @return EntitySearchResult|null
     * @throws Throwable
     */
    private function getAbandonedCartsForSalesChannel(SalesChannelEntity $salesChannelEntity, Context $context): ?EntitySearchResult
    {
        try {
            $criteria = new Criteria();
            $criteria->addFilter(new EqualsFilter('salesChannelId', $salesChannelEntity->getId()));
            $criteria->addAssociations(['customer', 'salesChannel', 'salesChannel.domains', 'salesChannel.mailHeaderFooter']);

            return $this->abandonedCartRepository->search($criteria, $context);
        } catch (Throwable $e) {
            $this->logOrThrowException($e);
        }

        return null;
    }

    /**
     * @return SalesChannelCollection
     * @throws \Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException
     */
    protected function getSalesChannels(): ?SalesChannelCollection
    {
        $result = $this->salesChannelRepository->search(
            new Criteria(),
            $this->getContext()
        );

        if ( $result->count() <= 0 )
            return null;

        /** @var SalesChannelCollection $salesChannelCollection */
        $salesChannelCollection = $result->getEntities();

        return $salesChannelCollection;
    }

    /**
     * @param Throwable $exception
     *
     * @return false
     * @throws Throwable
     */
    protected function logOrThrowException(Throwable $exception): bool
    {
        if ($this->isTestEnv()) {
            throw $exception;
        }

        $this->logger->critical($exception->getMessage());

        return false;
    }

    /**
     * @return bool
     */
    private function isTestEnv(): bool
    {
        return $this->environment === 'test' || $this->environment === 'dev';
    }

    /**
     * @return Context
     */
    private function getContext(): Context
    {
        return Context::createDefaultContext();
    }
}
