<?php

namespace Zeobv\AbandonedCart\Service;

use Shopware\Core\System\SalesChannel\SalesChannelEntity;
use Shopware\Core\System\SystemConfig\SystemConfigService;

/**
 * Class ConfigService
 *
 * @package Zeobv\AbandonedCart\Service
 */
class ConfigService {

    /**
     * @var SystemConfigService
     */
    protected $configService;

    /**
     * ConfigService constructor.
     *
     * @param SystemConfigService $configService
     */
    public function __construct(
        SystemConfigService $configService
    ) {
        $this->configService = $configService;
    }

    /**
     * @param SalesChannelEntity $salesChannelEntity
     *
     * @return bool|null
     */
    public function getIsActive(SalesChannelEntity $salesChannelEntity): ?bool
    {
        /** @var bool|null $isActive */
        $isActive = $this->configService->get('ZeobvAbandonedCart.config.active', $salesChannelEntity->getId());
        return !is_null($isActive) ? $isActive : false;
    }

    /**
     * @deprecated
     * @param SalesChannelEntity $salesChannelEntity
     *
     * @return int
     */
    public function getProcessStartDelay(SalesChannelEntity $salesChannelEntity): int
    {
        /** @var int|null $mailSendDelay */
        $mailSendDelay = $this->configService->get('ZeobvAbandonedCart.config.mailSendDelay', $salesChannelEntity->getId());
        return !is_null($mailSendDelay) ? $mailSendDelay : 1;
    }

    /**
     * @param SalesChannelEntity $salesChannelEntity
     *
     * @return int
     */
    public function getTrashDelay(SalesChannelEntity $salesChannelEntity): int
    {
        /** @var int|null $decayTime */
        $decayTime = $this->configService->get('ZeobvAbandonedCart.config.abandonedCartDecay', $salesChannelEntity->getId());
        return !is_null($decayTime) ? $decayTime : 24;
    }

    /**
     * @param SalesChannelEntity $salesChannelEntity
     *
     * @return bool
     */
    public function getIsCartAnonymous(SalesChannelEntity $salesChannelEntity): bool
    {
        /** @var bool|null $cartIsAnonymous */
        $cartIsAnonymous = $this->configService->get('ZeobvAbandonedCart.config.isCartAnonymous', $salesChannelEntity->getId());

        return !is_null($cartIsAnonymous) ? $cartIsAnonymous : false;
    }

    /**
     * @param SalesChannelEntity $salesChannelEntity
     *
     * @return array
     */
    public function getSchedule(SalesChannelEntity $salesChannelEntity): array
    {
        /** @var array|false $schedule */
        $schedule = json_decode($this->configService->getString('ZeobvAbandonedCart.config.schedule', $salesChannelEntity->getId()));

        return is_array($schedule) ? $schedule : [];
    }
}
