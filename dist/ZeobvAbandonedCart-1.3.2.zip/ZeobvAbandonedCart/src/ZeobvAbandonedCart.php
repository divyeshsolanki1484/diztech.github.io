<?php declare(strict_types=1);

namespace Zeobv\AbandonedCart;

use Shopware\Core\Content\MailTemplate\Aggregate\MailTemplateType\MailTemplateTypeEntity;
use Shopware\Core\Defaults;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Plugin;
use Shopware\Core\Framework\Plugin\Context\InstallContext;
use Shopware\Core\Framework\Plugin\Context\UninstallContext;
use Shopware\Core\Content\MailTemplate\MailTemplateEntity;

use Zeobv\AbandonedCart\Checkout\AbandonedCart\AbandonedCartDefinition;

class ZeobvAbandonedCart extends Plugin
{
    const MAIL_TEMPLATE_REMINDER_NAME = 'abandoned_cart.reminder';

    public function install(InstallContext $installContext): void
    {
        $mailTemplateRepository = $this->container->get('mail_template.repository');
        $mailTemplateTypeRepository = $this->container->get('mail_template_type.repository');

        $criteria = new Criteria();
        $criteria->addFilter(new EqualsFilter('technicalName', self::MAIL_TEMPLATE_REMINDER_NAME));
        $templateType = $mailTemplateTypeRepository->search($criteria, $installContext->getContext())->first();

        if ( $templateType instanceof MailTemplateTypeEntity) {
            return;
        }

        $mailTemplateRepository->create([
            [
                'systemDefault' => false,
                'translations' => [
                    [
                        'languageId' => Defaults::LANGUAGE_SYSTEM,
                        'subject' => 'Your cart is waiting for you',
                        'description' => 'Mail template send to customer who abandoned a shopping cart for longer than the configured time.',
                        'senderName' => '{{ salesChannel.name }}',
                        'contentPlain' => 'Your cart is waiting for you. Use the following link to go to checkout {{ url(\'frontend.zeo.abandonedcart.recover\', {id: zeoAbandonedCart.id}) }}',
                        'contentHtml' => '<h2>Your cart is waiting for you.</h2>
<p>Click the following link to proceed to checkout.<br/>
    <a href="{{ url(\'frontend.zeo.abandonedcart.recover\', {id: zeoAbandonedCart.id}) }}">
        <button>Go to checkout</button>
    </a>
</p>'
                    ]
                ],
                'mailTemplateType' => [
                    'technicalName' => self::MAIL_TEMPLATE_REMINDER_NAME,
                    'availableEntities' => [
                        'zeoAbandonedCart' => 'zeo_abandoned_cart',
                        'salesChannel' => 'sales_channel',
                        'customer' => 'customer'
                    ],
                    'translations' => [
                        [
                            'languageId' => Defaults::LANGUAGE_SYSTEM,
                            'name' => 'Enter abandoned cart state: Reminded'
                        ],
                    ]
                ]
            ]
        ], $installContext->getContext());
    }

    public function uninstall(UninstallContext $uninstallContext): void
    {
        if ($uninstallContext->keepUserData()) {
            return;
        }

        $connection = $this->container->get('Doctrine\DBAL\Connection');
        $abandonedCartsTable = AbandonedCartDefinition::ENTITY_NAME;
        $connection->exec("DROP TABLE IF EXISTS $abandonedCartsTable");

        $mailTemplateRepository = $this->container->get('mail_template.repository');
        $mailTemplateTypeRepository = $this->container->get('mail_template_type.repository');

        $criteria = new Criteria();
        $criteria->addAssociation('mailTemplateType');
        $criteria->addFilter(new EqualsFilter('mailTemplateType.technicalName', self::MAIL_TEMPLATE_REMINDER_NAME));
        $templates = $mailTemplateRepository->search($criteria, $uninstallContext->getContext());

        if ($templates->count() <= 0) {
            return;
        }

        $mailTemplateIds = [];
        $mailTemplateTypeIds = [];

        /** @var MailTemplateEntity $mailTemplate */
        foreach ($templates->getElements() as $mailTemplate) {
            $mailTemplateIds[] = ['id' => $mailTemplate->getId()];

            if (!in_array($mailTemplate->getMailTemplateTypeId(), $mailTemplateTypeIds)) {
                $mailTemplateTypeIds[] = ['id' => $mailTemplate->getMailTemplateTypeId()];
            }
        }

        if (!empty($mailTemplateIds)) {
            $mailTemplateRepository->delete($mailTemplateIds, $uninstallContext->getContext());
        }

        if (!empty($mailTemplateTypeIds)) {
            $mailTemplateTypeRepository->delete($mailTemplateTypeIds, $uninstallContext->getContext());
        }

        parent::uninstall($uninstallContext);
    }
}
