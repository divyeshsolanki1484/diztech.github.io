# 1.3.2
- Planungsfunktionen mit benutzerdefinierten E-Mail-Vorlagen zum Mailing für abgebrochene Warenkörbe hinzugefügt

# 1.3.1
- Problem mit der Dekoration in AbandonedCartService behoben

# 1.3.0
- Plugin kompatibel zu Shopware Version 6.4.0 gemacht

# 1.2.9
- Abwärtskompatibilität für die E-Mail-Planung erstellt. Diese Version bringt Planungsfunktionen für Shopware 6.3 ab 1.3.2

# 1.2.8
- Fehler in der Timing-Funktion behoben, der dazu führte, dass verlassene Wagen niemals weggeworfen oder Erinnerungen nie gesendet wurden

# 1.2.7
- Übersetzungsfehler in Mail-Vorlagen behoben 

# 1.2.6
- Fehlervermeidung zur geplanten Aufgabe hinzugefügt, um die Fortsetzung verlassener Warenkorb-Mails sicherzustellen

# 1.2.5
- Verbesserte Entitätsdefinition

# 1.2.4
- Problem behoben, bei dem Kopf- und Fußzeile von E-Mails nicht immer an die E-Mail angehängt wurden

# 1.2.3
- Fehler im Modal für verlassene Warenkorbdetails behoben, der die Navigation zum Produkt, auf das verwiesen wird, behinderte

# 1.2.2
- Verbesserte Erweiterbarkeit

# 1.2.1
- Kompatibilitäts-Patch mit dem ZeobvReorder-Plugin

# 1.2.0
- Kompatibilität der Backend-Bestellung hinzugefügt
- Funktion zum Anzeigen von Artikeln im verlassenen Warenkorb hinzugefügt

# 1.1.1
- v6.3.0.0 kompatibilitätsupdate

# 1.1.0
- Anonyme Warenkorboption hinzugefügt. Über die Konfiguration ist es jetzt möglich, der verlassenen Warenkorbpost zu erlauben, auch die Kundendaten zum Auschecken wiederherzustellen, oder die Warenkorbwiederherstellung nur den Warenkorbinhalt wiederherzustellen.
- Problem behoben, bei dem verlassene Warenkörbe bei Wiederherstellung oder Verfall nicht immer korrekt entfernt wurden.

# 1.0.4
- Wiederhergestellte Warenkorbartikel können jetzt entfernt werden.

# 1.0.3
- Gepatchtes Problem, bei dem nicht alle verlassenen Wagen verarbeitet würden, wenn ein Vertriebskanal keine verlassenen Wagen hätte.

# 1.0.2
- Gepatchtes Problem, bei dem über den Link in der E-Mail des verlassenen Warenkorbs kein neuer Warenkorb erstellt wurde
- Logo hinzugefügt

# 1.0.1
- Kompatibilitätskorrekturen für Shopware 6.1.0-rc3

# 1.0.0
- Erste Version des Zeo Abandoned Cart für Shopware 6
