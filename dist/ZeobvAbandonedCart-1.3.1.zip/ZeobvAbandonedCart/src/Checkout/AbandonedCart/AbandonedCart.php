<?php declare(strict_types=1);

namespace Zeobv\AbandonedCart\Checkout\AbandonedCart;

use Shopware\Core\Checkout\Customer\CustomerEntity;
use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityIdTrait;
use Shopware\Core\System\SalesChannel\Aggregate\SalesChannelDomain\SalesChannelDomainEntity;
use Shopware\Core\System\SalesChannel\SalesChannelEntity;

class AbandonedCart extends Entity
{
    use EntityIdTrait;

    /**
     * @var string
     */
    protected $cartToken;

    /**
     * @var string
     */
    protected $email;

    /**
     * @var bool
     */
    protected $mailSend;

    /**
     * @var array
     */
    protected $lineItems;

    /**
     * @var string
     */
    protected $salesChannelDomainId;

    /**
     * @var SalesChannelDomainEntity
     */
    protected $salesChannelDomain;

    /**
     * @var string
     */
    protected $customerId;

    /**
     * @var CustomerEntity
     */
    protected $customer;

    /**
     * @var SalesChannelEntity
     */
    protected $salesChannel;

    /**
     * @var string
     */
    protected $currencyId;

    /**
     * @var string
     */
    protected $paymentMethodId;

    /**
     * @var string
     */
    protected $shippingMethodId;

    /**
     * @var string
     */
    protected $countryId;

    /**
     * @var string
     */
    protected $salesChannelId;

    /**
     * @return string
     */
    public function getCartToken(): string
    {
        return $this->cartToken;
    }

    /**
     * @param string $cartToken
     */
    public function setCartToken(string $cartToken): void
    {
        $this->cartToken = $cartToken;
    }

    /**
     * @return string|null
     */
    public function getEmail(): ?string
    {
        return $this->email;
    }

    /**
     * @param string $email
     */
    public function setEmail($email): void
    {
        $this->email = $email;
    }

    /**
     * @return bool|null
     */
    public function getMailSend(): ?bool
    {
        return $this->mailSend;
    }

    /**
     * @param bool $mailSend
     */
    public function setMailSend(bool $mailSend): void
    {
        $this->mailSend = $mailSend;
    }

    /**
     * @return array
     */
    public function getLineItems(): array
    {
        return $this->lineItems;
    }

    /**
     * @param array $lineItems
     */
    public function setLineItems(array $lineItems): void
    {
        $this->lineItems = $lineItems;
    }

    /**
     * @return string
     */
    public function getSalesChannelDomainId(): string
    {
        return $this->salesChannelDomainId;
    }

    /**
     * @param string $salesChannelDomainId
     */
    public function setSalesChannelDomainId(string $salesChannelDomainId): void
    {
        $this->salesChannelDomainId = $salesChannelDomainId;
    }

    /**
     * @return SalesChannelDomainEntity
     */
    public function getSalesChannelDomain(): SalesChannelDomainEntity
    {
        return $this->salesChannelDomain;
    }

    /**
     * @param SalesChannelDomainEntity $salesChannelDomain
     */
    public function setSalesChannelDomain(SalesChannelDomainEntity $salesChannelDomain): void
    {
        $this->salesChannelDomain = $salesChannelDomain;
    }

    /**
     * @return string
     */
    public function getCustomerId(): string
    {
        return $this->customerId;
    }

    /**
     * @param string $customerId
     */
    public function setCustomerId(string $customerId): void
    {
        $this->customerId = $customerId;
    }

    /**
     * @return string
     */
    public function getCurrencyId(): string
    {
        return $this->currencyId;
    }

    /**
     * @param string $currencyId
     */
    public function setCurrencyId(string $currencyId): void
    {
        $this->currencyId = $currencyId;
    }

    /**
     * @return string
     */
    public function getPaymentMethodId(): string
    {
        return $this->paymentMethodId;
    }

    /**
     * @param string $paymentMethodId
     */
    public function setPaymentMethodId(string $paymentMethodId): void
    {
        $this->paymentMethodId = $paymentMethodId;
    }

    /**
     * @return string
     */
    public function getShippingMethodId(): string
    {
        return $this->shippingMethodId;
    }

    /**
     * @param string $shippingMethodId
     */
    public function setShippingMethodId(string $shippingMethodId): void
    {
        $this->shippingMethodId = $shippingMethodId;
    }

    /**
     * @return string
     */
    public function getCountryId(): string
    {
        return $this->countryId;
    }

    /**
     * @param string $countryId
     */
    public function setCountryId(string $countryId): void
    {
        $this->countryId = $countryId;
    }

    /**
     * @return string
     */
    public function getSalesChannelId(): string
    {
        return $this->salesChannelId;
    }

    /**
     * @param string $salesChannelId
     */
    public function setSalesChannelId(string $salesChannelId): void
    {
        $this->salesChannelId = $salesChannelId;
    }

    /**
     * @return CustomerEntity|null
     */
    public function getCustomer(): ?CustomerEntity
    {
        return $this->customer;
    }

    /**
     * @param CustomerEntity $customer
     */
    public function setCustomer(CustomerEntity $customer): void
    {
        $this->customer = $customer;
    }

    /**
     * @return SalesChannelEntity|null
     */
    public function getSalesChannel(): ?SalesChannelEntity
    {
        return $this->salesChannel;
    }

    /**
     * @param SalesChannelEntity $salesChannelEntity
     *
     * @return SalesChannelEntity
     */
    public function setSalesChannel(SalesChannelEntity $salesChannelEntity)
    {
        return $this->salesChannel = $salesChannelEntity;
    }

    /**
     * @return \DateInterval
     */
    public function getAge(): ?\DateInterval
    {
        try { # throws \Exception when the interval_spec cannot be parsed as an interval.
            return $this->getCreatedAt()->diff(new \DateTime());
        } catch (\Exception $e) {
            return null;
        }
    }
}
