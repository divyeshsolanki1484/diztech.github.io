# 1.0.4
- Wiederhergestellte Warenkorbartikel können jetzt entfernt werden.

# 1.0.3
- Gepatchtes Problem, bei dem nicht alle verlassenen Wagen verarbeitet würden, wenn ein Vertriebskanal keine verlassenen Wagen hätte.

# 1.0.2
- Gepatchtes Problem, bei dem über den Link in der E-Mail des verlassenen Warenkorbs kein neuer Warenkorb erstellt wurde
- Logo hinzugefügt

# 1.0.1
- Kompatibilitätskorrekturen für Shopware 6.1.0-rc3

# 1.0.0
- Erste Version des Zeo Abandoned Cart für Shopware 6
