# 1.2.0
- Backend order compatibility added
- Added function to view items in abandoned cart 

# 1.1.1
- v6.3.0.0 compatibility update

# 1.1.0
- Added anonymous cart option. Via the configuration it's now possible to allow the abandoned cart mail to also recover the customer data for checkout or to make the cart recovery only restore the cart contents.
- Fixed issue where abandoned cart would not always be removed correctly on recovery or deprecation.

# 1.0.4
- Recovered cart items are now removable.

# 1.0.3
- Patched issue where not all abandoned carts would be processed if a sales channel didn't have any abandoned carts.

# 1.0.2
- Patched issue where no new cart would be created using the link in the abandoned cart email
- Added logo

# 1.0.1
- Compatibility fixes for Shopware 6.1.0-rc3

# 1.0.0
- First version of the Zeo Abandoned Cart for Shopware 6
