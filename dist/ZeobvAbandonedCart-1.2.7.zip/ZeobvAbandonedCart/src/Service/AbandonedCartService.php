<?php

namespace Zeobv\AbandonedCart\Service;

use Symfony\Component\Routing\RouterInterface;
use Shopware\Core\Content\MailTemplate\Exception\SalesChannelNotFoundException;
use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;
use Shopware\Core\Checkout\Cart\Exception\InvalidQuantityException;
use Shopware\Core\Checkout\Cart\Exception\LineItemNotStackableException;
use Shopware\Core\Checkout\Cart\Exception\MixedLineItemTypeException;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Checkout\Cart\Cart;
use Shopware\Core\Content\MailTemplate\MailTemplateEntity;
use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\Uuid\Uuid;
use Shopware\Core\System\SalesChannel\Context\SalesChannelContextFactory;
use Shopware\Core\System\SalesChannel\Context\SalesChannelContextPersister;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Core\System\SalesChannel\SalesChannelEntity;
use Shopware\Core\System\SalesChannel\Context\SalesChannelContextService;
use Shopware\Core\Content\MailTemplate\Service\MailServiceInterface;
use Zeobv\AbandonedCart\Checkout\AbandonedCart\AbandonedCart;

class AbandonedCartService
{
    /**
     * @var ConfigService
     */
    protected $configService;

    /**
     * @var MailServiceInterface
     */
    protected $mailService;

    /**
     * @var EntityRepositoryInterface
     */
    protected $mailTemplateRepository;

    /**
     * @var EntityRepositoryInterface
     */
    protected $abandonedCartRepository;

    /**
     * @var CartService
     */
    protected $cartService;

    /**
     * @var SalesChannelContextPersister
     */
    protected $contextPersister;

    /**
     * @var SalesChannelContextFactory
     */
    private $salesChannelContextFactory;

    /**
     * @var RouterInterface
     */
    private $router;

    /**
     * AbandonedCartService constructor.
     *
     * @param ConfigService                $configService
     * @param EntityRepositoryInterface    $abandonedCartRepository
     * @param EntityRepositoryInterface    $mailTemplateRepository
     * @param MailServiceInterface         $mailService
     * @param CartService                  $cartService
     * @param SalesChannelContextPersister $contextPersister
     * @param SalesChannelContextFactory   $salesChannelContextFactory
     * @param RouterInterface              $router
     */
    public function __construct(
        ConfigService $configService,
        EntityRepositoryInterface $abandonedCartRepository,
        EntityRepositoryInterface $mailTemplateRepository,
        MailServiceInterface $mailService,
        CartService $cartService,
        SalesChannelContextPersister $contextPersister,
        SalesChannelContextFactory $salesChannelContextFactory,
        RouterInterface $router
    ) {
        $this->configService = $configService;
        $this->mailService = $mailService;
        $this->mailTemplateRepository = $mailTemplateRepository;
        $this->abandonedCartRepository = $abandonedCartRepository;
        $this->cartService = $cartService;
        $this->contextPersister = $contextPersister;
        $this->salesChannelContextFactory = $salesChannelContextFactory;
        $this->router = $router;
    }

    /**
     * @param SalesChannelEntity $salesChannelEntity
     *
     * @return bool
     */
    public function isActive(SalesChannelEntity $salesChannelEntity): bool
    {
        return $this->configService->getIsActive($salesChannelEntity);
    }

    /**
     * @param AbandonedCart $abandonedCart
     *
     * @return bool
     */
    public function shouldProcessAbandonedCart(AbandonedCart $abandonedCart): bool
    {
        return $this->isActive($abandonedCart->getSalesChannel()) &&
               !$abandonedCart->getMailSend() &&
               $this->canProcessAbandonedCart($abandonedCart) &&
               $abandonedCart->getAge()->h >= $this->configService->getProcessStartDelay($abandonedCart->getSalesChannel());
    }

    /**
     * @param AbandonedCart $abandonedCart
     *
     * @return bool
     */
    public function canProcessAbandonedCart(AbandonedCart $abandonedCart): bool
    {
        return !is_null($abandonedCart->getEmail()) || !is_null($abandonedCart->getCustomer());
    }

    /**
     * @param AbandonedCart $abandonedCart
     *
     * @throws SalesChannelNotFoundException
     * @throws InconsistentCriteriaIdsException
     */
    public function processAbandonedCart(AbandonedCart $abandonedCart)
    {
        // Load the SalesChannel context of the abandoned cart
        $salesChannelContext = $this->salesChannelContextFactory->create(
            Uuid::randomHex(),
            $abandonedCart->getSalesChannelId(),
            [
                SalesChannelContextService::LANGUAGE_ID => $abandonedCart->getSalesChannelDomain()->getLanguageId()
            ]
        );

        // Use the context of the Abandoned Cart SalesChannel
        $context = $salesChannelContext->getContext();

        // Setup the Symfony router context to simulate the Abandoned Cart SalesChannelDomain.
        // In console context the router context is not set and urls in email would fallback to http://localhost
        $originalRouterContext = clone $this->router->getContext();
        $this->switchRouterContext($abandonedCart->getSalesChannelDomain()->getUrl());

        $criteria = new Criteria();
        $criteria->addAssociation('mail_template_type.technicalName');
        $criteria->addFilter( new EqualsFilter('mailTemplateType.technicalName', 'abandoned_cart.reminder') );
        $result = $this->mailTemplateRepository->search($criteria, $context);

        if ($result->count() <= 0) {
            return;
        }

        /** @var MailTemplateEntity $template */
        $template = $result->first();

        # Map information of customer to template
        $mailData =  [
            'recipients' => [
                $abandonedCart->getCustomer()->getEmail() => $abandonedCart->getCustomer()->getFirstName()
            ],
            'salesChannelId' => $abandonedCart->getSalesChannelId(),
            'subject' => $template->getTranslation('subject'),
            'senderName' => $template->getTranslation('senderName'),
            'contentPlain' => $template->getTranslation('contentPlain'),
            'contentHtml' => $template->getTranslation('contentHtml'),
            'mediaIds' => []
        ];

        $templateData = $template->jsonSerialize();
        $templateData['zeoAbandonedCart'] = $abandonedCart;
        $templateData['salesChannel'] = $abandonedCart->getSalesChannel();
        $templateData['customer'] = $abandonedCart->getCustomer();

        # Create email
        $mailMessage = $this->mailService->send(
            $mailData,
            $context,
            $templateData
        );

        if ( $mailMessage instanceof \Swift_Message) {
            $this->abandonedCartRepository->update([
                ['id' => $abandonedCart->getId(), 'mailSend' => true]
            ], $context);
        }

        // Switch back to original router context
        $this->router->setContext($originalRouterContext);
    }

    /**
     * @param AbandonedCart $abandonedCart
     * @param Context       $context
     */
    public function resolveAbandonedCart(AbandonedCart $abandonedCart, Context $context)
    {
        # Cart is resolved to an order. The abandoned cart is no longer abandoned. Resolve the abandoned cart.
        $this->abandonedCartRepository->delete([
            ['id' => $abandonedCart->getId()]
        ], $context);
    }

    /**
     * An AbandonedCart should be trashed when it has been abandoned longer than the configured trash delay
     *
     * @param AbandonedCart $abandonedCart
     *
     * @return bool
     */
    public function shouldTrashAbandonedCart(AbandonedCart $abandonedCart): bool
    {
        return $abandonedCart->getAge()->h > $this->configService->getTrashDelay($abandonedCart->getSalesChannel()) ||
            (is_null($abandonedCart->getEmail()) && is_null($abandonedCart->getCustomer()));
    }

    /**
     * @param AbandonedCart $abandonedCart
     * @param Context       $context
     */
    public function trashAbandonedCart(AbandonedCart $abandonedCart, Context $context)
    {
        $this->abandonedCartRepository->delete([
            ['id' => $abandonedCart->getId()]
        ], $context);
    }

    /**
     * @param AbandonedCart       $abandonedCart
     * @param SalesChannelContext $salesChannelContext
     *
     * @return Cart
     * @throws InvalidQuantityException
     * @throws LineItemNotStackableException
     * @throws MixedLineItemTypeException
     */
    public function recoverAbandonedCart(AbandonedCart $abandonedCart, SalesChannelContext $salesChannelContext)
    {
        $newCart = $this->cartService->createNewFromAbandonedCart($abandonedCart, $salesChannelContext);
        $this->cartService->populateCartFromAbandonedCart($newCart, $abandonedCart, $salesChannelContext);

        $this->setNewCart($abandonedCart, $newCart, $salesChannelContext);
        $this->resolveAbandonedCart($abandonedCart, $salesChannelContext->getContext());

        if (!$this->configService->getIsCartAnonymous($salesChannelContext->getSalesChannel()) && $abandonedCart->getCustomer()) {
            $this->contextPersister->save(
                $salesChannelContext->getToken(),
                [
                    'customerId' => $abandonedCart->getCustomer()->getId(),
                    'billingAddressId' => $abandonedCart->getCustomer()->getDefaultBillingAddress() ?
                        $abandonedCart->getCustomer()->getDefaultBillingAddress()->getId() : null,
                    'shippingAddressId' => $abandonedCart->getCustomer()->getDefaultShippingAddress() ?
                        $abandonedCart->getCustomer()->getDefaultShippingAddress()->getId() : null,
                ]
            );
        }

        return $newCart;
    }

    /**
     * @param AbandonedCart       $abandonedCart
     * @param Cart                $newCart
     * @param SalesChannelContext $salesChannelContext
     *
     * @throws
     */
    public function setNewCart(AbandonedCart $abandonedCart, Cart $newCart, SalesChannelContext $salesChannelContext)
    {
        $this->cartService->setCartToSession($newCart, $salesChannelContext);
        $this->cartService->deleteRelatedCart($abandonedCart, $salesChannelContext);
        $this->cartService->saveNewCart($newCart, $salesChannelContext);
    }

    public function saveCart(Cart $cart, SalesChannelContext $salesChannelContext)
    {
        $this->cartService->saveNewCart($cart, $salesChannelContext);
    }

    /**
     * Switches the Symfony router context to another url
     * https://symfony.com/doc/4.4/routing.html#generating-urls-in-commands
     *
     *
     * Copied from Shopware:
     * Shopware\Storefront\Controller\ContextController@switchLanguage
     */
    protected function switchRouterContext(string $url){
        $parsedUrl = parse_url($url);

        $routerContext = $this->router->getContext();
        $routerContext->setHttpPort($parsedUrl['port'] ?? 80);
        $routerContext->setMethod('GET');
        $routerContext->setHost($parsedUrl['host']);
        $routerContext->setBaseUrl(rtrim($parsedUrl['path'] ?? '', '/'));
    }
}
