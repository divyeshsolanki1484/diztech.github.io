# 1.2.8
- Fixed bug in timing function causing abandoned carts to never be trashed or reminders to never be sent

# 1.2.7
- Fixed translation issue in mail templates 

# 1.2.6
- Added error prevention to scheduled task to ensure the continuation of abandoned cart mails 

# 1.2.5
- Improved entity definition

# 1.2.4
- Fixed issue where mail header and footer would not always be attached to the email

# 1.2.3
- Fixed bug in abandoned cart details modal which hindered navigating to the referenced product 

# 1.2.2
- Improved extendability

# 1.2.1
- Compatibility patch with ZeobvReorder plugin

# 1.2.0
- Backend order compatibility added
- Added function to view items in abandoned cart 

# 1.1.1
- v6.3.0.0 compatibility update

# 1.1.0
- Added anonymous cart option. Via the configuration it's now possible to allow the abandoned cart mail to also recover the customer data for checkout or to make the cart recovery only restore the cart contents.
- Fixed issue where abandoned cart would not always be removed correctly on recovery or deprecation.

# 1.0.4
- Recovered cart items are now removable.

# 1.0.3
- Patched issue where not all abandoned carts would be processed if a sales channel didn't have any abandoned carts.

# 1.0.2
- Patched issue where no new cart would be created using the link in the abandoned cart email
- Added logo

# 1.0.1
- Compatibility fixes for Shopware 6.1.0-rc3

# 1.0.0
- First version of the Zeo Abandoned Cart for Shopware 6
