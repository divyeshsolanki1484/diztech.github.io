<?php declare(strict_types = 1);

namespace Zeobv\AbandonedCart\Command\AbandonedCart;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

use Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException;

use Zeobv\AbandonedCart\ScheduledTasks\Handlers\AbandonedCart\CollectTaskHandler;

class Collect extends Command
{
    /**
     * @var CollectTaskHandler
     */
    private $collectTaskHandler;

    /**
     * OrderSync constructor.
     * @param CollectTaskHandler $collectTaskHandler
     * @param null $name
     */
    public function __construct(
        CollectTaskHandler $collectTaskHandler,
        $name = null
    )
    {
        $this->collectTaskHandler = $collectTaskHandler;

        parent::__construct($name);
    }


    protected function configure(): void
    {
        $this->setName('zeo:abandoned-cart:collect');
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     *
     * @return int
     * @throws InconsistentCriteriaIdsException
     */
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $output->writeln('Running Abandoned Cart CollectTask...');

        $this->collectTaskHandler->run();

        $output->writeln('Abandoned Cart CollectTask finished.');

        return 0;
    }
}
