<?php declare(strict_types=1);

namespace Zeobv\AbandonedCart\ScheduledTasks\Handlers\AbandonedCart;

use Shopware\Core\Framework\Context;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepositoryInterface;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\MessageQueue\ScheduledTask\ScheduledTaskHandler;
use Shopware\Core\System\SalesChannel\SalesChannelCollection;
use Shopware\Core\System\SalesChannel\SalesChannelEntity;
use Zeobv\AbandonedCart\Checkout\AbandonedCart\AbandonedCart;
use Zeobv\AbandonedCart\ScheduledTasks\Tasks\AbandonedCart\CollectTask;
use Zeobv\AbandonedCart\Service\AbandonedCartService;
use Throwable;
use Shopware\Core\Framework\DataAbstractionLayer\Search\EntitySearchResult;
use Psr\Log\LoggerInterface;

class CollectTaskHandler extends ScheduledTaskHandler
{
    /**
     * @var string
     */
    protected $environment;

    /**
     * @var EntityRepositoryInterface
     */
    protected $abandonedCartRepository;

    /**
     * @var EntityRepositoryInterface
     */
    protected $salesChannelRepository;

    /**
     * @var AbandonedCartService
     */
    protected $abandonedCartService;
    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * CollectTaskHandler constructor.
     *
     * @param string                    $environment
     * @param EntityRepositoryInterface $scheduledTaskRepository
     * @param EntityRepositoryInterface $abandonedCartRepository
     * @param EntityRepositoryInterface $salesChannelRepository
     * @param AbandonedCartService      $abandonedCartService
     * @param LoggerInterface           $logger
     */
    public function __construct(
        string $environment,
        EntityRepositoryInterface $scheduledTaskRepository,
        EntityRepositoryInterface $abandonedCartRepository,
        EntityRepositoryInterface $salesChannelRepository,
        AbandonedCartService $abandonedCartService,
        LoggerInterface $logger
    )
    {
        $this->environment = $environment;
        $this->abandonedCartRepository = $abandonedCartRepository;
        $this->salesChannelRepository = $salesChannelRepository;
        $this->abandonedCartService = $abandonedCartService;
        $this->logger = $logger;

        parent::__construct($scheduledTaskRepository);
    }

    /**
     * @return iterable
     */
    public static function getHandledMessages(): iterable
    {
        return [CollectTask::class];
    }

    /**
     * Collects all abandoned carts and starts the abandoned cart process
     */
    public function run(): void
    {
        try {
            $salesChannelCollection = $this->getSalesChannels();

            if (is_null($salesChannelCollection)) {
                return;
            }

            $context = $this->getContext();
            $this->abandonedCartService->setLastRunTimestamp();

            /** @var SalesChannelEntity $salesChannelEntity */
            foreach ($salesChannelCollection as $salesChannelEntity) {
                if (!$this->abandonedCartService->isActive($salesChannelEntity)) {
                    continue;
                }
                $this->abandonedCartService->setLastRunTimestamp($salesChannelEntity);

                $result = $this->getAbandonedCartsForSalesChannel($salesChannelEntity, $context);

                if (is_null($result) || $result->getTotal() <= 0) {
                    continue;
                }

                /** @var AbandonedCart $abandonedCart */
                foreach ($result->getElements() as $abandonedCart) {
                    $this->processAbandonedCart($abandonedCart, $context);
                }
            }
        } catch (Throwable $e) {
            $this->logOrThrowException($e);
        }
    }

    /**
     * @param AbandonedCart $abandonedCart
     * @param Context       $context
     *
     * @throws Throwable
     */
    protected function processAbandonedCart(AbandonedCart $abandonedCart, Context $context): void
    {
        try {
            # Check if abandoned cart should be processed
            if ($this->abandonedCartService->shouldProcessAbandonedCart($abandonedCart)) {
                # Process abandoned cart
                $this->abandonedCartService->processAbandonedCart($abandonedCart);
            } elseif ($this->abandonedCartService->shouldTrashAbandonedCart($abandonedCart)) {
                # Trash abandoned cart
                $this->abandonedCartService->trashAbandonedCart($abandonedCart, $context);
            }
        } catch (Throwable $e) {
            $this->logOrThrowException($e);
        }
    }

    /**
     * @param SalesChannelEntity $salesChannelEntity
     * @param Context            $context
     *
     * @return EntitySearchResult|null
     * @throws Throwable
     */
    private function getAbandonedCartsForSalesChannel(SalesChannelEntity $salesChannelEntity, Context $context): ?EntitySearchResult
    {
        try {
            $criteria = new Criteria();
            $criteria->addFilter(new EqualsFilter('salesChannelId', $salesChannelEntity->getId()));
            $criteria->addAssociations(['customer', 'salesChannel', 'salesChannel.domains', 'salesChannel.mailTemplates', 'salesChannel.mailHeaderFooter']);

            return $this->abandonedCartRepository->search($criteria, $context);
        } catch (Throwable $e) {
            $this->logOrThrowException($e);
        }

        return null;
    }

    /**
     * @return SalesChannelCollection
     * @throws \Shopware\Core\Framework\DataAbstractionLayer\Exception\InconsistentCriteriaIdsException
     */
    protected function getSalesChannels(): ?SalesChannelCollection
    {
        $result = $this->salesChannelRepository->search(
            new Criteria(),
            $this->getContext()
        );

        if ( $result->count() <= 0 )
            return null;

        /** @var SalesChannelCollection $salesChannelCollection */
        $salesChannelCollection = $result->getEntities();

        return $salesChannelCollection;
    }

    /**
     * @param Throwable $exception
     *
     * @return false
     * @throws Throwable
     */
    protected function logOrThrowException(Throwable $exception): bool
    {
        if ($this->isTestEnv()) {
            throw $exception;
        }

        $this->logger->critical($exception->getMessage());

        return false;
    }

    /**
     * @return bool
     */
    private function isTestEnv(): bool
    {
        return $this->environment === 'test' || $this->environment === 'dev';
    }

    /**
     * @return Context
     */
    private function getContext(): Context
    {
        return Context::createDefaultContext();
    }
}
