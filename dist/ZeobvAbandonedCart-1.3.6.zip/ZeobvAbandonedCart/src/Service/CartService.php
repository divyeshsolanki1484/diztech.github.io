<?php

namespace Zeobv\AbandonedCart\Service;

use Shopware\Core\Checkout\Cart\Cart;
use Shopware\Core\Checkout\Cart\CartPersister;
use Shopware\Core\Checkout\Cart\LineItem\LineItem;
use Shopware\Core\Checkout\Cart\LineItem\LineItemCollection;
use Shopware\Core\Checkout\Cart\SalesChannel\CartService as SwCartService;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Zeobv\AbandonedCart\Checkout\AbandonedCart\AbandonedCart;

class CartService {
    /**
     * @var SwCartService
     */
    protected $cartService;
    /**
     * @var CartPersister
     */
    protected $cartPersister;

    /**
     * CartService constructor.
     *
     * @param SwCartService      $cartService
     * @param CartPersister    $cartPersister
     */
    public function __construct(
        SwCartService $cartService,
        CartPersister $cartPersister
    ) {
        $this->cartService = $cartService;
        $this->cartPersister = $cartPersister;
    }

    /**
     * @param AbandonedCart       $abandonedCart
     * @param SalesChannelContext $salesChannelContext
     *
     * @return Cart
     */
    public function createNewFromAbandonedCart(AbandonedCart $abandonedCart, SalesChannelContext $salesChannelContext): Cart
    {
        return $this->cartService->createNew($salesChannelContext->getToken(), $abandonedCart->getId());
    }

    /**
     * @param Cart          $cart
     * @param AbandonedCart $abandonedCart
     *
     * @return Cart
     */
    public function populateCartFromAbandonedCart(Cart &$cart, AbandonedCart $abandonedCart): Cart
    {
        $lineItems = array_map(function (array $lineItemData) {
            return $this->createLineItemFromData($lineItemData);
        }, $abandonedCart->getLineItems());

        $lineItems = new LineItemCollection($lineItems);

        $cart->addLineItems($lineItems);

        return $cart;
    }

    /**
     * @param Cart $cart
     */
    public function setCartToSession(Cart &$cart): void
    {
        $this->cartService->setCart($cart);
    }

    /**
     * @param AbandonedCart       $abandonedCart
     * @param SalesChannelContext $salesChannelContext
     */
    public function deleteRelatedCart(AbandonedCart $abandonedCart, SalesChannelContext $salesChannelContext): void
    {
        $this->cartPersister->delete($abandonedCart->getCartToken(), $salesChannelContext);
    }

    /**
     * @param Cart                $cart
     * @param SalesChannelContext $salesChannelContext
     */
    public function saveNewCart(Cart $cart, SalesChannelContext $salesChannelContext): void
    {
        $this->cartPersister->save($cart, $salesChannelContext);
    }

    /**
     * @param array $lineItemData
     *
     * @return LineItem
     */
    private function createLineItemFromData(array $lineItemData): LineItem
    {
        $lineItem = new LineItem(
            $lineItemData['id'],
            $lineItemData['type'],
            $lineItemData['referencedId'],
            $lineItemData['quantity']
        );

        foreach ($lineItemData as $key => $value) {
            if (in_array($key, [
                'id',
                'type',
                'referencedId',
                'quantity',
                'modified',
                'cover',
                'price',
                'dataTimestamp',
                'priceDefinition',
                'deliveryInformation',
                'quantityInformation',
                'extensions',
            ]) || is_null($value)) {
                continue;
            }

            $setMethod = "set".ucfirst($key);

            switch ($key) {
                case "children":
                    $collection = new LineItemCollection();
                    foreach ($value as $lineItemChildData) {
                        $collection->add(
                            $this->createLineItemFromData($lineItemChildData)
                        );
                    }
                    $lineItem->setChildren($collection);
                    break;
                default:
                    $lineItem->$setMethod($value);
            }
        }

        return $lineItem;
    }
}
