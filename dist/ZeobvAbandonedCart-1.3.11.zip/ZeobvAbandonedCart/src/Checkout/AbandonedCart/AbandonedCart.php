<?php declare(strict_types=1);

namespace Zeobv\AbandonedCart\Checkout\AbandonedCart;

use DateTime;
use DateTimeImmutable;
use DateInterval;

use Shopware\Core\Checkout\Customer\CustomerEntity;
use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityIdTrait;
use Shopware\Core\System\SalesChannel\Aggregate\SalesChannelDomain\SalesChannelDomainEntity;
use Shopware\Core\System\SalesChannel\SalesChannelEntity;

/**
 * Class AbandonedCart
 *
 * @package Zeobv\AbandonedCart\Checkout\AbandonedCart
 */
class AbandonedCart extends Entity
{
    use EntityIdTrait;

    /**
     * @var string
     */
    protected $cartToken;

    /**
     * @var string
     */
    protected $email;

    /**
     * @var array
     */
    protected $lineItems;

    /**
     * @var string
     */
    protected $salesChannelDomainId;

    /**
     * @var string
     */
    protected $customerId;

    /**
     * @var string
     */
    protected $currencyId;

    /**
     * @var string
     */
    protected $paymentMethodId;

    /**
     * @var string
     */
    protected $shippingMethodId;

    /**
     * @var string
     */
    protected $countryId;

    /**
     * @var string
     */
    protected $salesChannelId;

    /**
     * @var int
     */
    protected $scheduleIndex;

    /**
     * @var DateTime|DateTimeImmutable|null
     */
    protected $lastMailSendAt;

    /**
     * @var CustomerEntity|null
     */
    protected $customer;

    /**
     * @var SalesChannelEntity|null
     */
    protected $salesChannel;

    /**
     * @var SalesChannelDomainEntity
     */
    protected $salesChannelDomain;

    /**
     * @var bool|null
     */
    protected $isRecovered;

    /**
     * @return string
     */
    public function getCartToken(): string
    {
        return $this->cartToken;
    }

    /**
     * @param string $cartToken
     */
    public function setCartToken(string $cartToken): void
    {
        $this->cartToken = $cartToken;
    }

    /**
     * @return string|null
     */
    public function getEmail(): ?string
    {
        return $this->email;
    }

    /**
     * @param string $email
     */
    public function setEmail($email): void
    {
        $this->email = $email;
    }

    /**
     * @return array
     */
    public function getLineItems(): array
    {
        return $this->lineItems;
    }

    /**
     * @param array $lineItems
     */
    public function setLineItems(array $lineItems): void
    {
        $this->lineItems = $lineItems;
    }

    /**
     * @return string
     */
    public function getCurrencyId(): string
    {
        return $this->currencyId;
    }

    /**
     * @param string $currencyId
     */
    public function setCurrencyId(string $currencyId): void
    {
        $this->currencyId = $currencyId;
    }

    /**
     * @return string
     */
    public function getPaymentMethodId(): string
    {
        return $this->paymentMethodId;
    }

    /**
     * @param string $paymentMethodId
     */
    public function setPaymentMethodId(string $paymentMethodId): void
    {
        $this->paymentMethodId = $paymentMethodId;
    }

    /**
     * @return string
     */
    public function getShippingMethodId(): string
    {
        return $this->shippingMethodId;
    }

    /**
     * @param string $shippingMethodId
     */
    public function setShippingMethodId(string $shippingMethodId): void
    {
        $this->shippingMethodId = $shippingMethodId;
    }

    /**
     * @return string
     */
    public function getCountryId(): string
    {
        return $this->countryId;
    }

    /**
     * @return string
     */
    public function getCustomerId(): string
    {
        return $this->customerId;
    }

    /**
     * @param string $customerId
     */
    public function setCustomerId(string $customerId): void
    {
        $this->customerId = $customerId;
    }

    /**
     * @return string
     */
    public function getSalesChannelDomainId(): string
    {
        return $this->salesChannelDomainId;
    }

    /**
     * @param string $salesChannelDomainId
     */
    public function setSalesChannelDomainId(string $salesChannelDomainId): void
    {
        $this->salesChannelDomainId = $salesChannelDomainId;
    }

    /**
     * @param string $countryId
     */
    public function setCountryId(string $countryId): void
    {
        $this->countryId = $countryId;
    }

    /**
     * @return int
     */
    public function getScheduleIndex(): int
    {
        return $this->scheduleIndex;
    }

    /**
     * @param int $scheduleIndex
     */
    public function setScheduleIndex(int $scheduleIndex): void
    {
        $this->scheduleIndex = $scheduleIndex;
    }

    /**
     * @return DateTime|DateTimeImmutable|null
     */
    public function getLastMailSendAt()
    {
        return $this->lastMailSendAt;
    }

    /**
     * @param DateTime $lastMailSendAt
     */
    public function setLastMailSendAt(DateTime $lastMailSendAt): void
    {
        $this->lastMailSendAt = $lastMailSendAt;
    }

    /**
     * @return string
     */
    public function getSalesChannelId(): string
    {
        return $this->salesChannelId;
    }

    /**
     * @param string $salesChannelId
     */
    public function setSalesChannelId(string $salesChannelId): void
    {
        $this->salesChannelId = $salesChannelId;
    }

    /**
     * @return CustomerEntity|null
     */
    public function getCustomer(): ?CustomerEntity
    {
        return $this->customer;
    }

    /**
     * @param CustomerEntity $customer
     */
    public function setCustomer(CustomerEntity $customer): void
    {
        $this->customer = $customer;
    }

    /**
     * @return SalesChannelEntity|null
     */
    public function getSalesChannel(): ?SalesChannelEntity
    {
        return $this->salesChannel;
    }

    /**
     * @param SalesChannelEntity $salesChannelEntity
     */
    public function setSalesChannel(SalesChannelEntity $salesChannelEntity): void
    {
        $this->salesChannel = $salesChannelEntity;
    }

    /**
     * @return SalesChannelDomainEntity
     */
    public function getSalesChannelDomain(): SalesChannelDomainEntity
    {
        return $this->salesChannelDomain;
    }

    /**
     * @param SalesChannelDomainEntity $salesChannelDomain
     */
    public function setSalesChannelDomain(SalesChannelDomainEntity $salesChannelDomain): void
    {
        $this->salesChannelDomain = $salesChannelDomain;
    }

    /**
     * @return DateInterval
     */
    public function getAge(): ?DateInterval
    {
        $date = !is_null($this->getUpdatedAt()) ? $this->getUpdatedAt() : $this->getCreatedAt();
        try { # throws \Exception when the interval_spec cannot be parsed as an interval.
            return $date->diff(new DateTime());
        } catch (\Exception $e) {
            return null;
        }
    }

    public function getisRecovered(): ?bool
    {
        return $this->isRecovered;
    }

    public function setisRecovered(?bool $isRecovered): void
    {
        $this->isRecovered = $isRecovered;
    }
}
