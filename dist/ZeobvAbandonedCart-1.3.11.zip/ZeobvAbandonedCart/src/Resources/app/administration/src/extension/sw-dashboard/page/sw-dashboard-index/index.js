import template from './sw-dashboard-index.html.twig';

const {Component, Defaults} = Shopware;
const {Criteria} = Shopware.Data;
Component.override('sw-dashboard-index', {
    template,
    inject: ['configService', 'systemConfigApiService'],

    data() {
        return {
            zeobvAbandonedCartorder: [],
            totalOrderCount: null,
            zeobvAbandonedCartMailConfig: null,
            zeobvAbandonedCartRatio: 0
        }
    },
    methods: {
        createdComponent() {
            this.fetchAbandonedCartOrders();
            this.$super('createdComponent');
        },

        fetchAbandonedCartOrders() {
            const criteriaOrder = new Criteria(1, 10);
            criteriaOrder.addFilter(Criteria.equals('customFields.ZeobvAbandonedCartMail', 1))
            this.orderRepository.search(criteriaOrder, Shopware.Context.api)
                .then(response => {
                    this.zeobvAbandonedCartorder = response;
                    this.totalOrderCount = response.total;
                    this.systemConfigApiService.getValues('ZeobvAbandonedCart.config')
                        .then((response) => {
                            if (this.totalOrderCount !== 0) {
                                this.zeobvAbandonedCartMailConfig = response['ZeobvAbandonedCart.config.metricMailsSent'] || null;

                                this.zeobvAbandonedCartRatio = ((this.totalOrderCount  / this.zeobvAbandonedCartMailConfig) * 100).toFixed(2);
                            } else {
                                this.zeobvAbandonedCartRatio = 0;
                            }
                        });
                });
        },

        zeobvAbandonedCartGridColumns() {
            return [{
                property: 'orderNumber',
                label: 'sw-order.list.columnOrderNumber',
                routerLink: 'sw.order.detail',
                allowResize: true,
                primary: true,
            }, {
                property: 'orderDateTime',
                dataIndex: 'orderDateTime',
                label: 'sw-dashboard.todayStats.orderTime',
                allowResize: true,
                primary: false,
            }, {
                property: 'orderCustomer.firstName',
                dataIndex: 'orderCustomer.firstName,orderCustomer.lastName',
                label: 'sw-order.list.columnCustomerName',
                allowResize: true,
            }, {
                property: 'stateMachineState.name',
                label: 'sw-order.list.columnState',
                allowResize: true,
            }, {
                property: 'amountTotal',
                label: 'sw-order.list.columnAmount',
                align: 'right',
                allowResize: true,
            }];
        },
    }

});
