import './module/zeo-abandoned-cart/component/zeobv-abandoned-cart-schedule-grid';
import './module/zeo-abandoned-cart/component/zeo-abandoned-cart-details-modal';
import './module/zeo-abandoned-cart/page/zeo-abandoned-cart-list';
import './module/zeo-abandoned-cart';

/* Extending dashboard to display abandoned cart recover orders */
import './extension/sw-dashboard/page/sw-dashboard-index';
